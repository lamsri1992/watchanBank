
<?php $__env->startSection('content'); ?>
<section class="section">
    <div class="row">
        <div class="col-lg-12">
            <div class="card">
                <div class="card-body">
                    <div class="pagetitle">
                        <h5 class="card-title fw-bold">
                            <i class="fas fa-history"></i>
                            STATEMENT
                        </h5>
                        <table id="tableBasic" class="table table-striped table-borderless nowrap">
                            <thead>
                                <tr>
                                    <th class="text-center">Trans::Code</th>
                                    <th class="text-center">วันที่ทำรายการ</th>
                                    <th class="text-center">ประเภท</th>
                                    <th class="">รายการ</th>
                                    <th class="text-center">จำนวน/กิโลกรัม</th>
                                    <th class="text-end">จำนวนเงิน</th>
                                    <th class="text-end">รวม</th>
                                    <th class="text-center">ผู้ทำรายการ</th>
                                    <th class="text-center">สถานะ</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $history; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $res): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td class="text-center"><?php echo e($res->tran_code); ?></td>
                                    <td class="text-center"><?php echo e(DateTimeThai($res->created_at)); ?></td>
                                    <td class="text-center">
                                        <span class="<?php echo e($res->ttype_color); ?> fw-bold">
                                            <?php echo $res->ttype_icon; ?>

                                        </span>
                                        <?php echo e($res->ttype_name); ?>  
                                    </td>
                                    <td class=""><?php echo e($res->item_name); ?></td>
                                    <td class="text-center"><?php echo e($res->tran_amount); ?></td>
                                    <td class="text-end"><?php echo e(number_format($res->tran_total / $res->tran_amount,2)." ฿"); ?></td>
                                    <td class="text-end">
                                        <span class="fw-bold">
                                            <?php echo e(number_format($res->tran_total,2)." ฿"); ?>

                                        </span>
                                    </td>
                                    <td class="text-center"><?php echo e($res->tran_create); ?></td>
                                    <td class="text-center">
                                        <span class="<?php echo e($res->t_status_color); ?> fw-bold">
                                            <?php echo $res->t_status_icon; ?>

                                        </span>
                                        <?php echo e($res->t_status_name); ?>

                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\SatiyaCH\all\watchanBank\resources\views/user/statement.blade.php ENDPATH**/ ?>